
Food Track - ZeroSpoil Starter Project
=====================================

This is a minimal Flutter starter project for the Food Track (ZeroSpoil) app. It includes:
- Basic UI screens: Home, Add Product (creates JSON payload), Scan Page (uses mobile_scanner)
- Logo asset
- pubspec.yaml with dependencies
- GitHub Actions workflow to build a debug APK in the cloud.

How to use:
1. Upload this project to a GitHub repository.
2. Ensure the .github/workflows/build-apk.yml file is committed.
3. Go to Actions tab in GitHub, wait for the build to run (or trigger manually).
4. Download the APK artifact "foodtrack-debug-apk" and install on an Android device.
