
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';

class AddProductPage extends StatefulWidget {
  const AddProductPage({super.key});
  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _mfd = TextEditingController();
  final _exp = TextEditingController();
  final uuid = const Uuid();
  String lastPayload = '';

  void createProduct() {
    if (!_form.currentState!.validate()) return;
    final batchId = 'BATCH-\${uuid.v4().substring(0,8)}';
    final payload = {
      "product_name": _name.text.trim(),
      "batch_id": batchId,
      "mfd": _mfd.text.trim(),
      "exp": _exp.text.trim(),
      "company_id": "FSSAI-TEST-001"
    };
    setState(() => lastPayload = json.encode(payload));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product JSON created. Use this as QR payload.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Product (Company)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Product Name'), validator: (v) => v==null||v.isEmpty? 'Enter name': null),
              TextFormField(controller: _mfd, decoration: const InputDecoration(labelText: 'MFG Date (YYYY-MM-DD)'), validator: (v)=> v==null||v.isEmpty? 'Enter mfg': null),
              TextFormField(controller: _exp, decoration: const InputDecoration(labelText: 'EXP Date (YYYY-MM-DD)'), validator: (v)=> v==null||v.isEmpty? 'Enter exp': null),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: createProduct, child: const Text('Create Product JSON (QR payload)')),
              const SizedBox(height: 12),
              SelectableText(lastPayload, maxLines: 10)
            ],
          ),
        ),
      ),
    );
  }
}
