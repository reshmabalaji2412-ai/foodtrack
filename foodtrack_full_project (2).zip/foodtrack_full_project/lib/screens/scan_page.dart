
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'dart:convert';

class ScanPage extends StatefulWidget {
  const ScanPage({super.key});
  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  String last = '';

  void handleScan(String raw) {
    setState(() => last = raw);
    try {
      final data = json.decode(raw);
      showDialog(context: context, builder: (_) {
        return AlertDialog(
          title: const Text('Product Scanned'),
          content: Text('Name: ${data['product_name']}\nBatch: ${data['batch_id']}\nMFD: ${data['mfd']}\nEXP: ${data['exp']}'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))
          ],
        );
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Scanned: $raw')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Product QR')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              allowDuplicates: false,
              onDetect: (capture) {
                final code = capture.barcodes.first.rawValue ?? '';
                handleScan(code);
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            child: Text('Last: \$last'),
          )
        ],
      ),
    );
  }
}
