
import 'package:flutter/material.dart';
import 'scan_page.dart';
import 'add_product.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Track - ZeroSpoil')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text("Scan Product QR"),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ScanPage()));
              },
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.add_box),
              label: const Text("Add Product (Company)"),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProductPage()));
              },
            ),
            const SizedBox(height: 20),
            const Text(
              "Use 'Add Product' to create sample product entries (company). Use 'Scan Product QR' to simulate Warehouse / Wholesaler / Shop scans.",
              textAlign: TextAlign.center,
            )
          ],
        ),
      ),
    );
  }
}
